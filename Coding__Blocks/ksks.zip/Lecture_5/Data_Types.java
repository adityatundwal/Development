package Lecture_5;

public class Data_Types {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		byte b = 6;
		int x = 90;
		short s = 11;
		long l = 89;

	}

}
