package lecture_2;
import java.util.Scanner;
public class Pattern_Question_6_Correct {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);   //Input
		int n = sc.nextInt();   //suppose input 5
		int row = 1;        // declared row value
		int space = 0;    // took space value according to pattern
		int star = n;    // took star value equivalent to n
		while(row <= n) { 
			int i = 1;
			while (i<=space) {
				System.out.print("  ");
				i++;
			}
			
			int j = 1;
			while(j<=star) {
				System.out.print("* ");
				j++;
			}
			
			row++;
			System.out.println();
			space+=2;
			star--;
		}

	}

}
