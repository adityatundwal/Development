package lecture_1;

public class Count_1_to_10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n = 10;
		int i = 1;
		
		while(i <= n) {
			System.out.println(i);
			i = i+1;
		}
	}

}
