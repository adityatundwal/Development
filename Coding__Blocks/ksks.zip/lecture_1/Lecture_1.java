package lecture_1;

public class Lecture_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//System.out.println("Hey");
		//System.out.println("Microsoft hacked"); 
		//System.out.println("Hello");
		
		
		System.out.println("Hey");
		System.out.print("Welcome to Coding Blocks");
		System.out.println("Bye");
		System.out.print("Hello");
		System.out.print("Okay");
		System.out.println("hii");
		
		
		
		
		
		
		
	}

}
