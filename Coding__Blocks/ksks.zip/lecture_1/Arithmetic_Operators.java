package lecture_1;

public class Arithmetic_Operators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a = 6;
		int b = 9;
		int c = a + b;
		System.out.println(c);
		c = a - b;
		System.out.println(c);
		int c1 = a * b;
		System.out.println(c1);
		int c2 = a % b;
		System.out.println(c2);
		int c3 = a / b;
		System.out.println(c3);


	}

}
