package lecture_1;

public class Assignment_operator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int x = 5;
		
		x += 3;
		
		System.out.println(x);
		

	}

}
