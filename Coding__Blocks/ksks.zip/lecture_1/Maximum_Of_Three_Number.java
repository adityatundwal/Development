package lecture_1;

public class Maximum_Of_Three_Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	 int a = 695;
	 int b = 750;
	 int c = 852;
	 
	 
	 if(a >= b && a >= c) {
		 System.out.println("A is the Maximum Number out of three");
	 }
	 else if(b >= a && b >= c) {
		 System.out.println("b is the maximum");
	 }
	 else {
		 System.out.println("C is the maximum number");
	 }
	 
	}

}





