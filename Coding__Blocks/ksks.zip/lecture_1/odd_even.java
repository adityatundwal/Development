package lecture_1;

public class odd_even {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int n = 89;
		
		if (n % 2 == 0) {
			System.out.println("Even");
		}
		else {
			System.out.println("odd");
		}

	}

}
