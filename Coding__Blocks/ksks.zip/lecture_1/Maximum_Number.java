package lecture_1;

public class Maximum_Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int a = 73;
		int b = 64;
		
		if (a < b) {
			System.out.println("B is the greatest");
			}
		if(a == b){
			System.out.println("Both are Equal");		
		}
		else{
			System.out.println("A is the greatest");
		}
	}
}
