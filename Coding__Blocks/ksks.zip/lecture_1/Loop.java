package lecture_1;

public class Loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int n = 5;
		
		int i = 1;
		
		while(i <=  n) {
			System.out.println("Hello");
			i = i+1;
		}
	}

}
