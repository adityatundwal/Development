package Lecture_6;

public class For_Loop_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		for(byte b = 0; b < 128; b++){   infitnite loop
//			System.out.println(b);
//		}
		
		
		for (byte b = 0; b<= 127; b++) {
			System.out.println(b);
		}
	}

}
