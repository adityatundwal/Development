package Lecture_6;

public class for_loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// int i = 1;
		//while(i<=5)
		
		//i++;
		for (int i = 1; i<=5; i++) {
			System.out.println(i);
		}

	}

}
