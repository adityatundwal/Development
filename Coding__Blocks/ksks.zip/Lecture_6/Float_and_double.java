package Lecture_6;

public class Float_and_double {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		float f = 7.9f;  //32 bit //writing f will convert it to literal float and consist of 32 bit
		double d = 7.9; //64bit
		boolean b = true; //1bit   0
		boolean b1 = false;//1bit  1

	}

}
