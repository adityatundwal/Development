package Lecture_6;

public class Char_Data_Type {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		char ch = 'a';
		char ch1 = '0';
		System.out.println((int)(ch));
		ch++; // ch = char (ch+1)
		System.out.println(ch);
	}

}
