package Lecture_6;

public class Type_Casting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		byte b = (byte)(428);  //explicit typecasting
		System.out.println(b);
		
		
		int i = 90;      //Implicit TypeCasting
		byte b1 = 15;
		i  = b1;
		System.out.println(i);
	}

}
